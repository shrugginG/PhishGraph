/*
 * This script replaces the standard modal-link's click event, which is set by the mwf.Modal script.
 * New click behavior: Before showing the modal, it checks whether a "redirect cookie" is set. If it is found, then instead
 * of opening the modal, we redirect the user to an authored URL.
 * Also adds the cookie when the Modal's `onHide` event is fired;
*/
(() => {
  "use strict";

  const redirectElKey = "[data-ocr-modal-redirect-id]";

  const datasetKeys = {
    cookieExpiration: "ocrModalCookieExpiration",
    redirectId: "ocrModalRedirectId",
    redirectUrl: "ocrModalRedirectionUrl"
  };

  /**
   * generate unique redirect ids
   * @param {NodeList} els 
   * @returns {Array} an array of unique redirect ids
   */
  const generateRedirectIds = (els) => {
    const ids = [];
    els.forEach(el => {
      ids.push(el.dataset[datasetKeys.redirectId]);
    });
    return Array.from(new Set(ids));
  }

  /**
   * Get the first element in a NodeList that has a specific redirect id.
   * @param {NodeList} els 
   * @param {String} id 
   * @returns {Node} the first element found by the redirect id
   */
  const getFirstElByRedirectId = (els, id) => {
    let res = null;
    els.forEach(el => {
      if (el.dataset[datasetKeys.redirectId] === id) {
        res = el;
      }
    });
    return res;
  }

  /**
   * Get reidrect url value from link's sibling element
   * @param {Node} link 
   * @returns {Stirng | null} the redirect url of the previous sibling
   */
  const getSiblingsRedirectUrl = (link) => {
    const redirectEl = link.nextElementSibling;
    if (redirectEl && redirectEl.dataset[datasetKeys.redirectUrl]) {
      return redirectEl.dataset[datasetKeys.redirectUrl];
    }
    return null;
  }

  /**
   * Set cookie
   * @param {string} key 
   * @param {string} value 
   * @param {number} expiration 
   */
  const setCookie = (key, value, expiration) => {
    const expDate = new Date();
    expDate.setTime(expDate.getTime() + expiration);
    document.cookie = `${key}={'dismissed':'${value}'};expires=${expDate.toUTCString()}`;
  };

  const cookieModalRedirectFunctions = () => {
    const redirectEls = document.querySelectorAll(redirectElKey);
    if (!redirectEls || redirectEls.length === 0) {
      console.error("No modal redirect elements found.");
      return;
    }
    const redirectIds = generateRedirectIds(redirectEls);


    redirectIds.forEach(id => {
      cookieModalRedirectFunction(getFirstElByRedirectId(redirectEls, id));
    });
  }

  const cookieModalRedirectFunction = (el) => {
    const { dataset } = el;
    const cookieExpiration = dataset[datasetKeys.cookieExpiration];
    const modalId = dataset[datasetKeys.redirectId]?.replace('#', ''); // Remove the leading #
    const redirectUrl = dataset[datasetKeys.redirectUrl];
    const cookieExpirationInDays = cookieExpiration ? parseInt(cookieExpiration, 10) * 1000 * 60 * 60 * 24 : 0;
    const cookieKey = `modal-redirect-dismissed-${window.location.href.split('?')[0].split('#')[0]}-${modalId}`; // Example: modal-redirect-dismissed-https://www.microsoft.com-modal-1
    const cookieValue = `true`;



    const modal = document.getElementById(modalId);
    if (!modal) {
      console.error("Modal element not found.");
      return;
    }

    const links = document.querySelectorAll(`[data-target="#${modalId}"]`);
    if (!links || links.length === 0) {
      console.error("Modal link not found.");
      return;
    }

    const modalInstances = window.ocrReimagine.ModalExtension.getInstances();
    let targetedModal = null;
    modalInstances.forEach(modalInstance => {
      if (modalInstance.el.id === modalId) {
        targetedModal = modalInstance;
      }
    });

    if (!targetedModal) {
      console.error("Targeted modal not found.");
      return;
    }

    const removeModalLinkClickEvent = (link) => {
      const linkClickEventHandler = targetedModal.events.find(event => event.el && event.el === link)?.handler;
      if (!linkClickEventHandler) {
        console.error("Link click event handler not found.");
        return;
      }
      link.removeEventListener("click", linkClickEventHandler);
    }

    const toggleModal = (redirectUrl) => {
      const cookieExists = document.cookie.split(';').some(item => item.trim().startsWith(`${cookieKey}=`));
      if (cookieExists) {
        window.location.href = redirectUrl;
      } else {
        targetedModal.toggle();
      }
    };

    links.forEach(link => {
        removeModalLinkClickEvent(link);
        link.addEventListener("click", () => {
          let url = getSiblingsRedirectUrl(link) || redirectUrl;
          toggleModal(url);
      });
    });

    targetedModal.el.addEventListener("onHide", () => {
      if (cookieExpirationInDays > 0) {
        setCookie(cookieKey, cookieValue, cookieExpirationInDays);
      }
    });
  };

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", cookieModalRedirectFunctions);
  } else {
    cookieModalRedirectFunctions();
  }

})();
